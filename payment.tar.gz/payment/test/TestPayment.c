#include "payment.h"
#include "unity.h"
#include "unity_fixture.h"

TEST_GROUP(payment);

TEST_SETUP(payment)
{
}

TEST_TEAR_DOWN(payment)
{
}

TEST(payment, TestPayment1)
{
  // All of these should pass
  float valor = 10.01;
  char* status = "gaucho";
  int esperado = 2;
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment2)
{
  // This test will fail
  float valor = 10001.01;
  char* status = "gaucho";
  int esperado = 0;
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment3)
{
  // This test will fail
  float valor = 20032.13;
  char* status = "a";
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment4)
{
  // This test will fail
  float valor = 30032.13;
  char* status = "VI";
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment5)
{
  // This test will fail
  float valor = 47801.01;
  char* status = "es2tudante";
  int esperado = 0;
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment6)
{
  // This test will fail
  float valor = 55432.13;
  char* status = "V1";
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment7)
{
  // This test will fail
  float valor = 65732.13;
  char* status = "reular";
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment8)
{
  // This test will fail
  float valor = 72001.44;
  char* status = "tudante";
  int esperado = 0;
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(2, payment(valor, status));
}

TEST(payment, TestPayment9)
{
  // This test will fail
  float valor = 81132.33;
  char* status = "VIP";
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(0, payment(valor, status));
}

TEST(payment, TestPayment10) //test payment 10: erro de valor esperado (1) mas retornou 0
{
  // This test will fail
  float valor = 9932.43;
  char* status = "regular";
  int resultado = payment(valor, status);
  TEST_ASSERT_EQUAL(0, payment(valor, status));
}
