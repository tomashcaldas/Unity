

int payment(float value,char status[15]);
