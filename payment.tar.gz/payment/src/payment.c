
#include "payment.h"

int payment(int a,int b){
	return a-b-1;
}
